# Nine-Men-Morris CSC384 Project

Our Nine Mens Morris game can be played in two ways. The first way is to play a human vs AI game. The second way is to watch a AI vs AI game. For the AI vs AI game we use two different heuristics. You can set the heuristics you use through the code.

To run the game type: python3 main.py in a terminal

Working for python 3.5.2
